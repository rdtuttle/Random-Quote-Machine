$(document).ready(function(){
  var randomQuote;
  var randomNum;
  var author;
  getQuote();
  
  function getQuote(){
    var quotes = ["You only need to hang mean bastards, but mean bastards you need to hang.","I like the way you die, boy!","Gentleman, you had my curiosity, now you have my attention.","If you shoot me in a dream you better wake up and apologize.","Say what again… I dare you… I double dare you, motherfucker!","Do you know what this is? It’s the world’s smallest violin playing just for the waitresses.","Wiggle your big toe."];
    var author1 = ["The Hateful Eight","Django Unchained","Django Unchained","Reservoir Dogs","Pulp Fiction","Reservoir Dogs","Kill Bill"];
    
     randomNum = Math.floor((Math.random()*quotes.length));
     randomQuote = quotes[randomNum];
    author = author1[randomNum];
    
    $(".quote").text(randomQuote);
    $(".author").text(author);
    
  }
  $("#tweet").on("click", function(){
    window.open("https://twitter.com/intent/tweet?text="+randomQuote+ " "+ author);
  });
  
  $("#newQuote").on("click", function(){
    getQuote();
    
  });
  
  
});